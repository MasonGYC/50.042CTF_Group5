# Srtucture of the submission folder:
1. attack_scipts:  
    the sample scipts for attcking our challange
    - ps: since some of the parts require manully guessing, the scipt only provide possible directions and bruteforce method.
2. related_files: 
    - the flag
    - the code that we use to generate the modified picture, full implementation
3. to_be_published: 
    the desciption, code, and image that need to be published 
4. write_ups
    - write-up
    - draft